


<div class=" card transactions_div_card transactions_div_main mt-8">
        <div class="d-flex justify-content-between mx-1 mt-1 mb-1">
            <h4>Recent History</h4>
            <button class="btn btn-outline-light">Select Dates</button>
        </div>


        <div class="transactions_div">












        
        <div class="card card2 transaction-card">
            <div class="card-header transaction-header">
                <div class="d-flex align-items-center">
                    <img src="https://via.placeholder.com/40" class="rounded-circle me-2" alt="Profile Picture">
                    <div>
                        <div class="fw-bold">Brandon Stark</div>
                        <small>@brandonstark@kosh</small>
                    </div>
                </div>
                <div class="transaction-info">
                    <div class="text-end">
                        <div>02 Feb</div>
                        <div class="text-success">+10.2 GDC</div>
                    </div>
                    <div class="arrow-btn collapsed" data-bs-toggle="collapse" data-bs-target="#details1" aria-expanded="false" aria-controls="details1">
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </div>
            <div id="details1" class="collapse transaction-details">
                <p><strong>Date:</strong> 2/2/2024</p>
                <p><strong>Time:</strong> 1:20:10 PM</p>
                <p><strong>Transaction Charge:</strong> 0 GDC</p>
                <p><strong>Transaction Id:</strong> PWW4Xj4bB0b85SwJRR5tUrWYoKYAm8ERtQKX1mAZ2xc=</p>
                <p><strong>Message (Optional):</strong> Hello, world!</p>
                <p><strong>Tag:</strong> Travel</p>
            </div>
        </div>

        <div class="card card2 transaction-card">
            <div class="card-header transaction-header">
                <div class="d-flex align-items-center">
                    <img src="https://via.placeholder.com/40" class="rounded-circle me-2" alt="Profile Picture">
                    <div>
                        <div class="fw-bold">Brandon Stark</div>
                        <small>@brandonstark@kosh</small>
                    </div>
                </div>
                <div class="transaction-info">
                    <div class="text-end">
                        <div>02 Feb</div>
                        <div class="text-danger">-10.2 GDC</div>
                    </div>
                    <div class="arrow-btn collapsed" data-bs-toggle="collapse" data-bs-target="#details2" aria-expanded="false" aria-controls="details2">
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </div>
            <div id="details2" class="collapse transaction-details">
                <p><strong>Date:</strong> 2/2/2024</p>
                <p><strong>Time:</strong> 1:20:10 PM</p>
                <p><strong>Transaction Charge:</strong> 0 GDC</p>
                <p><strong>Transaction Id:</strong> PWW4Xj4bB0b85SwJRR5tUrWYoKYAm8ERtQKX1mAZ2xc=</p>
                <p><strong>Message (Optional):</strong> Hello, world!</p>
                <p><strong>Tag:</strong> Travel</p>
            </div>
        </div>
        <div class="card card2 transaction-card">
            <div class="card-header transaction-header">
                <div class="d-flex align-items-center">
                    <img src="https://via.placeholder.com/40" class="rounded-circle me-2" alt="Profile Picture">
                    <div>
                        <div class="fw-bold">Brandon Stark</div>
                        <small>@brandonstark@kosh</small>
                    </div>
                </div>
                <div class="transaction-info">
                    <div class="text-end">
                        <div>02 Feb</div>
                        <div class="text-success">+10.2 GDC</div>
                    </div>
                    <div class="arrow-btn collapsed" data-bs-toggle="collapse" data-bs-target="#details3" aria-expanded="false" aria-controls="details3">
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </div>
            <div id="details3" class="collapse transaction-details">
                <p><strong>Date:</strong> 2/2/2024</p>
                <p><strong>Time:</strong> 1:20:10 PM</p>
                <p><strong>Transaction Charge:</strong> 0 GDC</p>
                <p><strong>Transaction Id:</strong> PWW4Xj4bB0b85SwJRR5tUrWYoKYAm8ERtQKX1mAZ2xc=</p>
                <p><strong>Message (Optional):</strong> Hello, world!</p>
                <p><strong>Tag:</strong> Travel</p>
            </div>
        </div>

        <div class="card card2 transaction-card">
            <div class="card-header transaction-header">
                <div class="d-flex align-items-center">
                    <img src="https://via.placeholder.com/40" class="rounded-circle me-2" alt="Profile Picture">
                    <div>
                        <div class="fw-bold">Brandon Stark</div>
                        <small>@brandonstark@kosh</small>
                    </div>
                </div>
                <div class="transaction-info">
                    <div class="text-end">
                        <div>02 Feb</div>
                        <div class="text-danger">-10.2 GDC</div>
                    </div>
                    <div class="arrow-btn collapsed" data-bs-toggle="collapse" data-bs-target="#details4" aria-expanded="false" aria-controls="details4">
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </div>
            <div id="details4" class="collapse transaction-details">
                <p><strong>Date:</strong> 2/2/2024</p>
                <p><strong>Time:</strong> 1:20:10 PM</p>
                <p><strong>Transaction Charge:</strong> 0 GDC</p>
                <p><strong>Transaction Id:</strong> PWW4Xj4bB0b85SwJRR5tUrWYoKYAm8ERtQKX1mAZ2xc=</p>
                <p><strong>Message (Optional):</strong> Hello, world!</p>
                <p><strong>Tag:</strong> Travel</p>
            </div>
        </div>

















        </div>
    </div>